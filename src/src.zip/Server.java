import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;

public class Server {
  public static void main (String[] args) throws Exception {
    //port numbers from args
	int tcpPort;
    int udpPort;
    
    //to keep track of the store inventory (read in from inventory.txt and modified)
    ArrayList<String> supplies = new ArrayList<String>();
    ArrayList<Integer> quantities = new ArrayList<Integer>();
    
    //to keep track of what orders people have placed (from client)
    ArrayList<Integer> orderIDs = new ArrayList<Integer>();
    ArrayList<String> userName = new ArrayList<String>();
    ArrayList<String> myProductName = new ArrayList<String>();
    ArrayList<String> myOrder = new ArrayList<String>();

    
    DatagramPacket datapacket,returnpacket;
	DatagramSocket datasocket = new DatagramSocket();
	int len = 1024;
	byte[] buf = new byte[len];
	int orderID = 0;
	
	//ensures there are the 3 arguments provided
    if (args.length != 3) {
      System.out.println("ERROR: Provide 3 arguments");
      System.out.println("\t(1) <tcpPort>: the port number for TCP connection");
      System.out.println("\t(2) <udpPort>: the port number for UDP connection");
      System.out.println("\t(3) <file>: the file of inventory");

      System.exit(-1);
    }
    
    //decodes the 3 arguments
    tcpPort = Integer.parseInt(args[0]);
    udpPort = Integer.parseInt(args[1]);
    String fileName = args[2];

    // parse the inventory file
    BufferedReader br = new BufferedReader(new FileReader(fileName));
    String line;
    while(null != (line = br.readLine())){
    	String[] tokens = line.split(" ");
    	if(tokens.length != 2){
    		throw new IOException();
    	}
    	supplies.add(tokens[0]);
    	quantities.add(Integer.parseInt(tokens[1]));
    }
    
    // TODO: handle request from clients
    
    //do this infinitley
    while(true){
    	//recieve the client request
    	datapacket = new DatagramPacket(buf, buf.length);
		datasocket.receive(datapacket);
		
		//parse the byte stream back to string
		String s = new String(buf, "UTF-8");
		String[] tokens = s.split(" ");
		
		//if this is a purchase do this
		if(tokens[0].equals("purchase")){
			//How we get the data:
			//purchase <user-name> <product-name> <quantity> T|U 
			//tokens[0] = 'purchase'     tokens[1] = user name
			//tokens[2] = product		 tokens[2] = quantity
			String rString = s;
			int indexSupplies = supplies.indexOf(tokens[2]);
			
			//checks if we sell this type of item
			if(indexSupplies < 0){
				rString = "Not Available - We do not sell this product";
			}
			
			//checks if we have enough of the item
			else if(quantities.get(indexSupplies) < Integer.parseInt(tokens[3])){
				rString = "Not Available - Not enough items";
			}
			
			//modifies the count, gives the userID, add to the order lists, write the appropriate return string
			else {
				int newQuant = quantities.get(indexSupplies) - Integer.parseInt(tokens[3]);
				quantities.set(indexSupplies, newQuant);
				orderID++;
				rString = "You order has been placed, " + orderID + " " + rString;
				orderIDs.add(orderID);
			    userName.add(tokens[1]);
			    myProductName.add(tokens[2]);
			    myOrder.add(tokens[3]);
			}
			
			//send the data back to the client
			byte[] buffer = rString.getBytes("UTF-8");
			returnpacket = new DatagramPacket(
					buffer,
					buffer.length,
					datapacket.getAddress(),
					datapacket.getPort());
			datasocket.send(returnpacket);
		}
		
		//if this is a cancel
		else if(tokens[0].equals("cancel")){
			//cancel <order-id> T|U
			String rString = s;
			//checks if the orderID is present
			int indexID = orderIDs.indexOf(tokens[1]);
			
			//if orderID is not there return not found
			if(indexID < 0){
				rString = tokens[1] + " not found, no such order";
			}
			
			//else remove order from all of the lists...lol
			else {
				rString = "Order " + tokens[1] + " is canceled";
				orderIDs.remove(indexID);
			    userName.remove(indexID);
			    myProductName.remove(indexID);
			    myOrder.remove(indexID);
				
			}
			byte[] buffer = rString.getBytes("UTF-8");
			returnpacket = new DatagramPacket(
					buffer,
					buffer.length,
					datapacket.getAddress(),
					datapacket.getPort());
			datasocket.send(returnpacket);
		}
		
		//if this is a search
		else if(tokens[0].equals("search")){
			//search <user-name> T|U
			String rString = s;
			//checks if the user is in the database
			int indexName = userName.indexOf(tokens[1]);
			if(indexName < 0){
				rString = "No order found for " + tokens[1];
			}
			
			//if in the database...iterates through all users in order to see all instances of the user
			else {
				int i = 0;
				for(String currUser: userName){
					if(currUser.equals(tokens[1])){
						//return string: <order-id>, <product-name>, <quantity>
						rString += orderIDs.get(i) + ", " + myProductName.get(i) + ", " + myOrder.get(i) + "\n";
					}
					i++;
				}
			}
			byte[] buffer = rString.getBytes("UTF-8");
			returnpacket = new DatagramPacket(
					buffer,
					buffer.length,
					datapacket.getAddress(),
					datapacket.getPort());
			datasocket.send(returnpacket);
		}
		
		//if this is a list
		else if(tokens[0].equals("list")){
			//list T|U
			//goes through all items in supplies and quantities to list out the current inventory
			int sizeInv = supplies.size();
			String rString = new String();
			for(int i=0; i<sizeInv; i++){
				rString += supplies.get(sizeInv) + quantities.get(sizeInv) + "\n";
			}
			byte[] buffer = rString.getBytes("UTF-8");
			returnpacket = new DatagramPacket(
					buffer,
					buffer.length,
					datapacket.getAddress(),
					datapacket.getPort());
			datasocket.send(returnpacket);
		}
    }
  }
}